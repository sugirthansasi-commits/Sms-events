# SMS Events — Full-Stack Version

This package keeps the existing colorful frontend and adds a lightweight Node.js backend.

## Backend functions
- `POST /api/enquiries` — saves customer event enquiries to `data/enquiries.json`.
- `GET /api/enquiries` — returns saved enquiries for an admin/dashboard integration.
- `POST /api/enquiries/status` — updates an enquiry: `new`, `contacted`, `confirmed`, or `cancelled`.
- `POST /api/plans` — stores generated AI event plans in `data/plans.json`.
- `GET /api/health` — backend health check.

## Run on Windows
1. Install Node.js 18+.
2. Open Command Prompt in this folder.
3. Run `node server.js` (or `npm start`).
4. Open `http://localhost:3000`.

Data is stored locally as JSON so the project is easy to understand for a college project. For production, replace the JSON storage with MySQL/PostgreSQL/MongoDB and add authentication.
