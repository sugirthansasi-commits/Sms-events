const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'enquiries.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, '[]');

function readEnquiries(){ try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8') || '[]'); } catch { return []; } }
function writeEnquiries(data){ fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2)); }
function send(res, status, data, type='application/json'){ res.writeHead(status, {'Content-Type': type, 'Access-Control-Allow-Origin':'*','Cache-Control':'no-store'}); res.end(type==='application/json'?JSON.stringify(data):data); }
function body(req){ return new Promise((resolve,reject)=>{ let b=''; req.on('data',c=>{ b+=c; if(b.length>1e6) req.destroy(); }); req.on('end',()=>{ try{resolve(b?JSON.parse(b):{});}catch(e){reject(e);} }); req.on('error',reject); }); }
function clean(v, max=1000){ return String(v ?? '').trim().slice(0,max); }

const server=http.createServer(async (req,res)=>{
  if(req.method==='OPTIONS'){ res.writeHead(204, {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}); return res.end(); }
  const url=new URL(req.url, `http://${req.headers.host}`);
  try{
    if(url.pathname==='/api/health') return send(res,200,{ok:true,service:'SMS Events Backend',time:new Date().toISOString()});
    if(url.pathname==='/api/enquiries' && req.method==='POST'){
      const x=await body(req);
      const required=['name','phone','eventType','eventDate','venue'];
      const missing=required.filter(k=>!clean(x[k]));
      if(missing.length) return send(res,400,{ok:false,error:'Missing required fields',fields:missing});
      const item={id:crypto.randomUUID(),createdAt:new Date().toISOString(),status:'new',name:clean(x.name,120),phone:clean(x.phone,40),email:clean(x.email,160),eventType:clean(x.eventType,80),eventDate:clean(x.eventDate,30),venue:clean(x.venue,200),guests:clean(x.guests,20),budget:clean(x.budget,60),plan:clean(x.plan,5000),message:clean(x.message,2000)};
      const all=readEnquiries(); all.unshift(item); writeEnquiries(all);
      return send(res,201,{ok:true,message:'Enquiry saved successfully',enquiryId:item.id});
    }
    if(url.pathname==='/api/enquiries' && req.method==='GET'){
      const all=readEnquiries();
      return send(res,200,{ok:true,count:all.length,enquiries:all});
    }
    if(url.pathname==='/api/enquiries/status' && req.method==='POST'){
      const x=await body(req); const id=clean(x.id,100); const status=clean(x.status,30);
      if(!id || !['new','contacted','confirmed','cancelled'].includes(status)) return send(res,400,{ok:false,error:'Invalid id or status'});
      const all=readEnquiries(); const i=all.findIndex(e=>e.id===id); if(i<0) return send(res,404,{ok:false,error:'Enquiry not found'});
      all[i].status=status; all[i].updatedAt=new Date().toISOString(); writeEnquiries(all); return send(res,200,{ok:true,enquiry:all[i]});
    }
    if(url.pathname==='/api/plans' && req.method==='POST'){
      const x=await body(req); const item={id:crypto.randomUUID(),createdAt:new Date().toISOString(),event:clean(x.event,100),concept:clean(x.concept,10000),budget:clean(x.budget,100)};
      const file=path.join(DATA_DIR,'plans.json'); let all=[]; try{all=JSON.parse(fs.readFileSync(file,'utf8')||'[]')}catch{} all.unshift(item); fs.writeFileSync(file,JSON.stringify(all,null,2)); return send(res,201,{ok:true,planId:item.id});
    }
    // Static frontend
    let filePath=url.pathname==='/'?path.join(ROOT,'index.html'):path.join(ROOT,path.normalize(url.pathname).replace(/^\.{2}[\\/]/,''));
    if(!filePath.startsWith(ROOT)) return send(res,403,{error:'Forbidden'});
    if(fs.existsSync(filePath) && fs.statSync(filePath).isFile()){
      const ext=path.extname(filePath); const types={'.html':'text/html','.css':'text/css','.js':'application/javascript','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.txt':'text/plain'};
      res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'}); return fs.createReadStream(filePath).pipe(res);
    }
    return send(res,404,{error:'Not found'});
  }catch(e){ console.error(e); return send(res,500,{ok:false,error:'Server error'}); }
});
server.listen(PORT,()=>console.log(`SMS Events running at http://localhost:${PORT}`));
